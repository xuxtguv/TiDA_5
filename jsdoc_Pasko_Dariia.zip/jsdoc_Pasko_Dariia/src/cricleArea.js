/**
 * Funkcja oblicza pole koła na podstawie podanej wartości promienia.
 * @param {number }radius Liczba. która jest promieniem koła.
 * @returns {number|string} Zwraca wynik obliczenia pola koła; jeśli promień jest mniejszy lub równy zero - wypisuje komunikat błędu.
 * @throws {Error} Rzuca wyjątek, gdy promień jest mniejszy lub równy zero.
 *
 * @author Dariia Pashko 5D
 */

function calculateArea(radius){
    if (radius <= 0){
       throw new Error('Promień musi być liczbą dodatnią.')
    }
    return Math.PI * radius * radius
}
try{
    console.log(calculateArea(5))
    console.log(calculateArea(10))
    console.log(calculateArea(-3))
}catch (error){
    console.error(error.message)
}