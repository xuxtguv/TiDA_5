/**
 * Funkcja na podstawie podanego wieku sprawdza, czy osoba jest pełnoletnia.
 * @param {number} age Liczba, która jest wiekiem
 * @returns {boolean|string} Zwraca 'true' jeśli wiek jest równy lub większy niż 18 lat, 'false' jeśli wiek jest poniżej 18 lat oraz komunikat błędu jeśli wiek jest liczbą ujemną
 * @throws {Error} Rzuca wyjątek, jeśli wiek jest liczbą ujemną bądź równą zero.
 *
 * @author Dariia Pashko 5D
 */

function isAdult(age){
    if (age <=0 ){
        throw new Error('Wiek musi być liczbą dodatnią')
    }
    return age >=18
}

try{
    console.log(isAdult(20))
    console.log(isAdult(17))
    console.log(isAdult(18))
    console.log(isAdult(-5))
}catch (error){
    console.error(error.message)
}