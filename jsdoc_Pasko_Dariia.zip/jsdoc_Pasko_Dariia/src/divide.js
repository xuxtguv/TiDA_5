/**
 * Funkcja wykonuje dzielenie dwóch liczb.
 * @param {number} dividend Liczba, którą dzielimy
 * @param {number }divisor Liczba, przez którą dzielimy
 * @returns {number|string} Wynik dzielenia, jeśli dzielnik jest różny od zera; w przeciwnym razie komunikat o błędzie.
 * @throws {Error} Rzuca wyjątek, gdy dzielnik jest równy zero.
 *
 * @example
 *
 * const a = 20;
 * const b = 10;
 *
 * const result = divide(a,b);
 * console.log(result);
 * // Logs: 2
 *
 * @author Dariia Pashko, 5D
 */
function divide(dividend, divisor){
    if (divisor === 0) {
       throw new Error('Błąd: Dzielenie przez zero jest niedozwolone.');
    }
    return dividend / divisor;
}

try{
    console.log(divide(10, 2));
    console.log(divide(10, 0));
}catch (error){
    console.error(error.message);
}