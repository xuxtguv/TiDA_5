/**
 * Funkcja wysyła powiadomienie z powitalną wiadomością dla podanej osoby
 * @param {string} somebody Imię osoby, do której kierujemy powitanie.
 * @returns {void} Ta funkcja nie zwraca żadnej wartości. Wywołuje jedynie powiadomienie.
 *
 * @author Dariia Pashko 5D
 */

const sayHello = (somebody) => {
    alert (`Hello ${somebody}`)
}